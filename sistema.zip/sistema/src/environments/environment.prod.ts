export const environment = {
  firebase: {
   projectId: "admisala-306cb",
    appId: "1:350506996824:web:45190cfa62fc587399a62d",
    storageBucket: "admisala-306cb.appspot.com",
    apiKey: "AIzaSyAWlKsplFeop180E55qSyo9LH-TX5xDgLo",
    authDomain: "admisala-306cb.firebaseapp.com",
    messagingSenderId: "350506996824",
  },
  production: true
};
