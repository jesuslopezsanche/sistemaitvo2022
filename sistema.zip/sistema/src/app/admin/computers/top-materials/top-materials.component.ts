import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-materials',
  templateUrl: './top-materials.component.html',
  styleUrls: ['./top-materials.component.css']
})
export class TopMaterialsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
